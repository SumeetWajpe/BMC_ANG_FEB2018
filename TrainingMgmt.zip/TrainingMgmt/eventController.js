﻿eventModule.controller('eventController', function ($scope) {

    $scope.TrainingDetails = {
            Name: 'AngularJS',       
            Location: 'Pune',
        Duration:'3 Days',
            Price: 5000,
            ImageUrl: 'http://blog.debugme.eu/wp-content/uploads/2016/03/learn-angularjs-1024x576.jpg',
            Rating: 4,
            Sessions: [
                      { Title: 'Basics Of Angular',Rating:3, Duration: '1 Hour', Level: 'Introductory', Votes: 0 },
        { Title: 'Basics Of Directives', Rating: 4, Duration: '3 Hours', Level: 'Intermidiate', Votes: 0 },
        { Title: 'Services in Details', Rating: 5, Duration: '2 Hours', Level: 'Advanced', Votes: 0 },
        { Title: 'Using AJAX in Angular', Rating: 4, Duration: '4 Hours', Level: 'Intermidiate', Votes: 0 },
        { Title: 'Using Filters', Rating: 3, Duration: '1 Hour', Level: 'Advanced', Votes: 0 }

            ]

    }

    $scope.ChangeHeading = function () {
        $scope.TrainingDetails.Name = " Angular JS 1.5";
    }

    $scope.ChangeOnInput = function (e) {
        $scope.TrainingDetails.Name = e.target.value;
    }


    $scope.IncrementVotes = function (s) {
       
        s.Votes = s.Votes + 1;
    }

    $scope.DecrementVotes = function (s) {
        s.Votes = s.Votes - 1;

    }
})